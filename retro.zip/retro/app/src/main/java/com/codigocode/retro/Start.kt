package com.codigocode.retro

import java.io.Serializable

data class Start(val name: String, val mass: String): Serializable